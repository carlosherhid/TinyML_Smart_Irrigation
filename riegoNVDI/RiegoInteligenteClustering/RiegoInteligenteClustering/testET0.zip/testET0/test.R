library(magrittr)

dmeteo <- data.table::fread("MU62.csv", sep = ";") %>%
  dplyr::select(c(fecha,hora,tmed,hrmed,vvmed,radmed)) %>%
  dplyr::mutate(FechaHora = paste(fecha,hora) %>% lubridate::dmy_hms()) %>%
  dplyr::arrange(FechaHora)

dmeteo$fecha %<>% lubridate::dmy()

testthat::test_that("hourly data", {
  tiempos <- dmeteo$FechaHora
  intervalos <- difftime(tiempos[-1], tiempos[-length(tiempos)], units = "hours")
  testthat::expect_equal(all(intervalos == 1), TRUE)
})

diasenteros <- dmeteo %>% dplyr::count(fecha) %>%
  dplyr::filter(n == 24) %>% dplyr::pull(fecha)

dmeteo %<>% dplyr::filter(fecha %in% diasenteros)

##################### INDIVIDUAL
aux <- capture.output(
  dmeteo %>%
    split(f = dmeteo$fecha) %>%
    lapply(function(m){
      ET.PenmanMonteith::et0(
        dates = m$FechaHora,
        temp  = m$tmed,
        hr    = m$hrmed,
        uz    = m$vvmed,
        rs    = m$radmed,
        lat   = 37.94006667,
        elev  = 56)
    }) -> et0s, type = "message"
)

et0.split <- dplyr::bind_rows(et0s)

##################### COLLECTIVE
aux <- capture.output(
  ET.PenmanMonteith::et0(
    dates = dmeteo$FechaHora,
    temp  = dmeteo$tmed,
    hr    = dmeteo$hrmed,
    uz    = dmeteo$vvmed,
    rs    = dmeteo$radmed,
    lat   = 37.94006667,
    elev  = 56) -> et0.df, type = "message"
)

testthat::test_that("individual vs collective computation correcteness", {
  testthat::expect_equal(et0.df$et0, et0.split$et0)
})

testthat::test_that("individual vs collective computation correcteness 0 tolerance", {
  testthat::expect_equal(all(et0.df$et0 == et0.split$et0), TRUE)
})

